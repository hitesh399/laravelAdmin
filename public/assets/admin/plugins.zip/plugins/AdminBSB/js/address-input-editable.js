function(t) {
    "use strict";
    var e = function(t) {
        this.init("address", t, e.defaults)
    };
    t.fn.editableutils.inherit(e, t.fn.editabletypes.abstractinput), t.extend(e.prototype, {
        render: function() {
            this.$input = this.$tpl.find("input")
        },
        value2html: function(e, i) {
            if (!e) return void t(i).empty();
            var s = t("<div>").text(e.city).html() + ", " + t("<div>").text(e.street).html() + " st., bld. " + t("<div>").text(e.building).html();
            t(i).html(s)
        },
        html2value: function(t) {
            return null
        },
        value2str: function(t) {
            var e = "";
            if (t)
                for (var i in t) e = e + i + ":" + t[i] + ";";
            return e
        },
        str2value: function(t) {
            return t
        },
        value2input: function(t) {
            t && (this.$input.filter('[name="city"]').val(t.city), this.$input.filter('[name="street"]').val(t.street), this.$input.filter('[name="building"]').val(t.building))
        },
        input2value: function() {
            return {
                city: this.$input.filter('[name="city"]').val(),
                street: this.$input.filter('[name="street"]').val(),
                building: this.$input.filter('[name="building"]').val()
            }
        },
        activate: function() {
            this.$input.filter('[name="city"]').focus()
        },
        autosubmit: function() {
            this.$input.keydown(function(e) {
                13 === e.which && t(this).closest("form").submit()
            })
        }
    }), e.defaults = t.extend({}, t.fn.editabletypes.abstractinput.defaults, {
        tpl: '<div class="form-group"><div class="form-line"><input type="text" class="form-control input-small" name="city" placeholder="City"></div></div><div class="form-group"><div class="form-line"><input type="text" class="form-control input-small" name="street" placeholder="Street"></div></div><div class="form-group"><div class="form-line"><input type="text" class="form-control input-small" name="building" placeholder="Building"></div></div>',
        inputclass: " form-control"
    }), t.fn.editabletypes.address = e
}(window.jQuery);